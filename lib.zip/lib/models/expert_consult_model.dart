
import 'package:flutter/cupertino.dart';

class ExpertConsultModel{

  String ? name;

  String? email;

  String? content;

  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final contentController = TextEditingController();

  Future<void> upload() async {

  }
}