import 'package:flutter/material.dart';
import 'package:phytopathy_prediction/phytopathy_prediction_app.dart';

void main() {
  runApp(PhytopathyPredictionAPP());
}
